#!/bin/bash

java -cp homework1-1.0.jar edu.nyu.cs9053.homework1.Homework $1 $2